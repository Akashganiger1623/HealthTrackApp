package com.example.stayhealthy_android_app.Diet;

public interface FoodCheckedListener {
    void onFoodChecked(int position, boolean isChecked);
}
