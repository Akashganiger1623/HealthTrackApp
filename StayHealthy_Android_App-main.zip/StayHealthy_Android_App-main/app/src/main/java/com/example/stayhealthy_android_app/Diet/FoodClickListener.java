package com.example.stayhealthy_android_app.Diet;

public interface FoodClickListener {
    void onFoodClicked(int position);
}
