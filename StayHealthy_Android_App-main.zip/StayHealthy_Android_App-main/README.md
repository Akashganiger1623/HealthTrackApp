# StayHealthy_Android_App
This is a repository for the final project of CS5520 Summer 2022. <br />Team5 members are Minjie Shen, Shasha Wang, Fangxin Gu and Jing Ming. <br />StayHealthy is a daily-use Android app that encourages people, especially females, to maintain fitness habits and a healthy lifestyle by tracking exercise data, diet data, and health records which include the women’s periods.<br />
### Please visit our app walkthrough video for more information:  <br /> 
https://www.youtube.com/watch?v=rdBupA5WDug
